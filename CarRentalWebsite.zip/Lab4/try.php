<?php
include("connect.php");
// SQL query
$sql = "SELECT * FROM customer";
$result = $conn->query($sql);

// Check if there are rows in the result
// Output data of each row
while ($row = $result->fetch_assoc()) {
    echo "<pre>";
    print_r($row);
    echo "</pre>";
}

if ($result->num_rows > 0) {
    // Output data of each row
    echo "<table border='1'>";
    echo "<tr><th>Column1</th><th>Column2</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr><td>" . $row["customerId"] . "</td><td>" . $row["username"] . "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}

// Close connection
$conn->close();
?>