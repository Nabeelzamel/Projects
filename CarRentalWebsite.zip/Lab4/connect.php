<?php

$user = 'root';
$pass = '';
$db = 'rent';

$con = new mysqli('localhost', $user, $pass, $db) or die("Unable to Connect");
?>