/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sample;

import eg.edu.alexu.csd.oop.game.GameObject;

/**
 *
 * @author eyada
 */
public class MovingState extends State {

    public MovingState(GameObject g) {
        super(g);
    }
    @Override
    public void move(int x, int y) {
        g.setX(x);
        g.setY(y);
    }
}