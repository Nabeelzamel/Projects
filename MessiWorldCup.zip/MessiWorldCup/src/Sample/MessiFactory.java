/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sample;

import Object.ImageObject;
import Object.CupObject;
import Strategies.IStrategy;
import World.StadiumWorld;
import eg.edu.alexu.csd.oop.game.GameObject;

public class MessiFactory {

    private MessiFactory() {
    }
    
    private static MessiFactory single = null;
    
    public static MessiFactory getSingle() {
        if (single == null) {
            single = new MessiFactory();
        }
        return single;
    }

    public GameObject getShape(String type, int x, int y) {
        if (type == null) {
            return null;
        }
        else if (type.equals("plate")) {
            int random = (int) (Math.random() * 1000) % 2 + 1;
            return new CupObject(x, y, "/worldCup" + random + ".png", 2);
        }
        else if (type.equals("image")) {
            return new ImageObject(x, y, "/messi.png");
        }
        return null;
    }
}

