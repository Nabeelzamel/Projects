/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package Sample;

/**
 *
 * @author eyada
 */
public interface Subject {
    public void attach(Observer observer);
    public void notifyAllObservers();
    public void setstate(String state);
    public String getstate();
}
