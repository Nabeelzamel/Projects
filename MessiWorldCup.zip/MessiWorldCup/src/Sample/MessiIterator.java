/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sample;

/**
 *
 * @author eyada
 */
import eg.edu.alexu.csd.oop.game.GameObject;
import java.util.Iterator;
import java.util.List;

public class MessiIterator implements Iterator<GameObject> {

    int index = 0;
    List<GameObject> x;

    public MessiIterator(List<GameObject> x) {
        this.x = x;
    }

    @Override
    public boolean hasNext() {
        if (index < x.size()) {
            return true;
        } else {
            return false;
        }
    }

    @Override
    public GameObject next() {
        return x.get(index++);
    }
}

