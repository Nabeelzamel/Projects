/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sample;
import eg.edu.alexu.csd.oop.game.GameObject;

public abstract class State {

    protected GameObject g;

    public State(GameObject g) {
        this.g = g;
    }

    public abstract void move(int x, int y);
}
