package Strategies;

import Sample.*;


public interface IStrategy {

    public int getSpeed();

    public int getTimeout();
}
