/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Strategies;

import Sample.*;

/**
 *
 * @author eyada
 */
public class HardStrategy implements IStrategy{
    @Override
    public int getSpeed() {
        return 4;
    }

    @Override
    public int getTimeout() {
        return 2;
    }
}
