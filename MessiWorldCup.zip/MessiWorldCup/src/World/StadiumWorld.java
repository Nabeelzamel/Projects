package World;

import Object.ImageObject;
import Object.CupObject;
import Sample.MessiFactory;
import Strategies.IStrategy;
import Sample.MessiIterator;
import Sample.MovingState;
import java.util.LinkedList;
import java.util.List;

import eg.edu.alexu.csd.oop.game.GameObject;
import eg.edu.alexu.csd.oop.game.World;
import java.awt.Color;

public class StadiumWorld implements World {

    private static final int MAX_TIME = 1 * 60 * 1000;	// 1 minute
    private int score = 0;
    private final long startTime = System.currentTimeMillis();
    private final int width;
    private final int height;
    private final List<GameObject> constant = new LinkedList<GameObject>();
    private final List<GameObject> moving = new LinkedList<GameObject>();
    private final List<GameObject> control = new LinkedList<GameObject>();
    private List<GameObject> left = new LinkedList<GameObject>();
    private List<GameObject> right = new LinkedList<GameObject>();
    private IStrategy current;
    private static StadiumWorld single = null;

    public void setCurrent(IStrategy current) {
        this.current = current;
    }

    public StadiumWorld(IStrategy x, int screenWidth, int screenHeight) {

        current = x;
        width = screenWidth;
        height = screenHeight;
        MessiFactory factory = MessiFactory.getSingle();
        ImageObject stadium = new ImageObject(0, 0, "/newStadium.png");
        constant.add(stadium);
        control.add(factory.getShape("image", screenWidth / 3, (int) (screenHeight * 0.7)));
        for (int i = 0; i < 15; i++) {
            CupObject p = (CupObject) factory.getShape("plate", (int) (Math.random() * 800), 0 - (int) (Math.random() * 600));
            p.setDirection((int) (Math.random() * 1000 % 2));
            moving.add(p);
        }
    }


    private boolean intersect(GameObject o1, GameObject o2) {
        return (Math.abs((o1.getX() + o1.getWidth() / 2) - (o2.getX() + o2.getWidth() / 2)) <= o1.getWidth()) && (Math.abs((o1.getY() + o1.getHeight() / 2) - (o2.getY() + o2.getHeight() / 2)) <= o1.getHeight());
    }

//    @Override
//    public boolean refresh() {
//        boolean timeout = System.currentTimeMillis() - startTime > MAX_TIME; // time end and game over
//        GameObject messi = control.get(0);
//        MovingState movingClown = new MovingState(messi);
//        MessiIterator iterator = new MessiIterator(moving);
//        if(messi.getX()>=width)
//            movingClown.move(width, 0);
//        if(messi.getX()<=0)
//            movingClown.move(0, 0);
//        // moving starts
//        while(iterator.hasNext()) {
//            CupObject m = (CupObject) iterator.next();
//            MovingState movingM = new MovingState(m);
//            //System.out.println(Math.random() * 1000 % 2);
////            if (m.getX() + 20 < width / 2 && m.getY() == 15) {
////                movingM.move((int) (m.getX() + current.getSpeed()),m.getY());
////                //m.setX((int) (m.getX() + current.getSpeed()));
////            } else if (m.getX() - 100 > width / 2 && m.getY() == 15) {
////                movingM.move((int) (m.getX() - current.getSpeed()),m.getY());
////                //m.setX((int) (m.getX() - current.getSpeed()));
////            } else {
////                if (m.getType() == 2) {
////                    if (m.getDirection() == 1) {
////                        movingM.move((int)(m.getX() + Math.random() * 1000 % 3),(int)(m.getY() + Math.random() * 1000 % 3));
//////                        m.setX((int) (m.getX() + Math.random() * 1000 % 3));
//////                        m.setY((int) (m.getY() + Math.random() * 1000 % 3));
////                    } else {
////                        movingM.move((int) (m.getX() - Math.random() * 1000 % 3),(int) (m.getY() + Math.random() * 1000 % 3));
//////                        m.setX((int) (m.getX() - Math.random() * 1000 % 3));
//////                        m.setY((int) (m.getY() + Math.random() * 1000 % 3));
////                    }
////                }
////                else {
////                    m.setX((int) (m.getX() - 1));
////                    m.setY((int) (m.getY() + Math.random() * 1000 % 3));
////                }
////            }
//            movingM.move(m.getX(), m.getY()+current.getSpeed());
//
//            if (clownIntersectleft(m)) {
//
//                moving.remove(m);
//                CupObject p = (CupObject) m;
//                p.setC((ImageObject) messi);
//                p.setX(messi.getX() + 8);
//                p.setY(messi.getY() - p.getHeight());
//                p.setHorizontalOnly(true);
//                p.setType(1);
//                control.add(m);
//                left.add(m);
//            } else if (clownIntersectright(m)) {
//                moving.remove(m);
//                CupObject p = (CupObject) m;
//                p.setC((ImageObject) messi);
//                p.setX(messi.getX() + width - 8);
//                p.setY(messi.getY() - p.getHeight());
//                p.setHorizontalOnly(true);
//                p.setType(1);
//                control.add(m);
//                right.add(m);
//            } else {
//                if (!left.isEmpty()) {
//                    if (intersect(m, left.get(left.size() - 1))) {
//                        moving.remove(m);
//                        CupObject p = (CupObject) m;
//                        p.setC((ImageObject) messi);
//                        p.setX(messi.getX() + 8);
//                        p.setY(messi.getY() - p.getHeight());
//                        p.setHorizontalOnly(true);
//                        p.setY(left.get(left.size() - 1).getY() );
//                        p.setType(0);
//                        control.add(m);
//                        left.add(m);
//                    }
//                }
//                if (!right.isEmpty()) {
//                    if (intersect(m, right.get(right.size() - 1))) {
//                        moving.remove(m);
//                        CupObject p = (CupObject) m;
//                        p.setC((ImageObject) messi);
//                        p.setX(messi.getX() + width - 8);
//                        p.setY(messi.getY() - p.getHeight());
//                        p.setHorizontalOnly(true);
//                        p.setY(right.get(right.size() - 1).getY() - p.getWidth());
//                        p.setType(0);
//                        control.add(m);
//                        right.add(m);
//                    }
//                }
//                if (m.getX() >= width || m.getY() >= height) {
//                    movingM.move((int) (Math.random() * 800), 0-(int) (Math.random() * 600));
//                }
//            }
//            updateLeft();
//            updateRight();
//
//            if (left.size() == 10) {
//                return true;
//            }
//            if (right.size() == 10) {
//                return true;
//            }
//        }
//        return !timeout;
//    }
    @Override
    public boolean refresh() {
        boolean timeout = System.currentTimeMillis() - startTime > MAX_TIME; // time end and game over
        GameObject messi = control.get(0);
        MessiFactory factory = MessiFactory.getSingle();
        // moving starts
        MessiIterator iterator = new MessiIterator(moving);
        if (moving.isEmpty()) {
            for (int i = 0; i < 15; i++) {
                CupObject p = (CupObject) factory.getShape("plate", (int) (Math.random() * 800), 0 - (int) (Math.random() * 600));
                p.setDirection((int) (Math.random() * 1000 % 2));
                moving.add(p);
            }
        }
        while (iterator.hasNext()) {
            GameObject m = iterator.next();
            CupObject p = (CupObject) m;
            MovingState movingP = new MovingState(p);
            int x = m.getX();
            int y = m.getY();
            
            movingP.move(x, y + current.getSpeed());
            if (left.isEmpty()) {
                if (clownIntersectleft(m)) {
                    moving.remove(m);
                    p.setC((ImageObject) messi);
                    movingP.move(messi.getX() + 8, messi.getY() - p.getHeight());
                    p.setHorizontalOnly(true);
                    //p.setType(0);
                    control.add(m);
                    left.add(m);
                }
            } else {
                if (intersect(m, left.get(left.size() - 1))) {
                    moving.remove(m);
                    p.setC((ImageObject) messi);
                    if(p.getX()>8){
                    movingP.move(messi.getX() + 8, left.get(left.size() - 1).getY() - p.getHeight());}
                    p.setHorizontalOnly(true);
                    //p.setType(1);
                    control.add(m);
                    left.add(m);
                }
            }
            if (right.isEmpty()) {
                if (clownIntersectright(m)) {
                    moving.remove(m);
                    p.setC((ImageObject) messi);
                    movingP.move(messi.getX() + messi.getWidth() - 25, messi.getY() - p.getHeight());
                    p.setHorizontalOnly(true);
                    //p.setType(0);
                    control.add(m);
                    right.add(m);
                }
            } else {
                if (intersect(m, right.get(right.size() - 1))) {
                    moving.remove(m);
                    p.setC((ImageObject) messi);
                    movingP.move(messi.getX() + messi.getWidth() - 25, right.get(right.size() - 1).getY() - p.getHeight());
                    p.setHorizontalOnly(true);
                  //  p.setType(1);
                    control.add(m);
                    right.add(m);
                }
            }
            if (m.getX() >= width || m.getY() >= height) {
                movingP.move((int) (Math.random() * 800), 0 - (int) (Math.random() * 600));
            }
            updateLeft();
            updateRight();
            if (left.size() == 10) {
                return true;
            }
            if (right.size() == 10) {
                return true;
            }
        }
        return !timeout;
    }

    @Override
    public int getSpeed() {
        return 10;
    }

    @Override
    public int getControlSpeed() {
        return 20;
    }

    @Override
    public List<GameObject> getConstantObjects() {
        return constant;
    }

    @Override
    public List<GameObject> getMovableObjects() {
        return moving;
    }

    @Override
    public List<GameObject> getControlableObjects() {
        return control;
    }

    @Override
    public int getWidth() {
        return width;
    }

    @Override
    public int getHeight() {
        return height;
    }

    @Override
    public String getStatus() {
        return "Score=" + score + "   |   Time=" + Math.max(0, (MAX_TIME - (System.currentTimeMillis() - startTime)) / 1000);	// update status
    }

    private boolean clownIntersectleft(GameObject o) {
        ImageObject clown = (ImageObject) control.get(0);
        return (Math.abs(clown.getX() - o.getX()) <= o.getWidth() + 20
                && o.getY() == control.get(0).getY() - 40);
    }

    private boolean clownIntersectright(GameObject o) {
        ImageObject clown = (ImageObject) control.get(0);
        return (Math.abs((clown.getX() + clown.getWidth() / 1.5) - o.getX()) <= o.getWidth() + 20
                && o.getY() == control.get(0).getY() - 40);
    }

    private void updateLeft() {
        if (left.size() >= 3) {
            CupObject p1 = (CupObject) left.get(left.size() - 1);
            CupObject p2 = (CupObject) left.get(left.size() - 2);
            CupObject p3 = (CupObject) left.get(left.size() - 3);
            if (p1.getPath().equals(p2.getPath()) && p2.getPath().equals(p3.getPath())) {
                left.remove(left.size() - 1);
                left.remove(left.size() - 1);
                left.remove(left.size() - 1);
                control.remove(p1);
                control.remove(p2);
                control.remove(p3);
                score++;
            }
        }
    }

    private void updateRight() {
        if (right.size() >= 3) {
            CupObject p1 = (CupObject) right.get(right.size() - 1);
            CupObject p2 = (CupObject) right.get(right.size() - 2);
            CupObject p3 = (CupObject) right.get(right.size() - 3);
            if (p1.getPath().equals(p2.getPath()) && p2.getPath().equals(p3.getPath())) {
                right.remove(right.size() - 1);
                right.remove(right.size() - 1);
                right.remove(right.size() - 1);
                control.remove(p1);
                control.remove(p2);
                control.remove(p3);
                score++;
            }
        }
    }

}
